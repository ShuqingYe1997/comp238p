#if !defined(__CONSOLE_H__)
#define __CONSOLE_H__

void uartinit(void); 
void printk(char *);

#endif
