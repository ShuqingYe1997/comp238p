unsigned int main(int a, int b) {
    return a + b;
}

//void main(void) {
//    sum(a, b)
//};
